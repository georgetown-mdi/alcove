import * as psi from 'psi_';
export type MatchResult = {
    readonly intersectionSize: number;
    readonly decryptedCount: number;
    readonly associationTable?: readonly [Uint32Array, Uint32Array];
};
export type Match = {
    readonly delete: () => void;
    readonly addSetupBytes: (bytes: Uint8Array) => void;
    readonly sealSetup: () => void;
    readonly matchResponsePiece: (bytes: Uint8Array) => void;
    readonly finish: () => MatchResult;
};
export declare const MatchConstructor: (instance: psi.Match) => Match;
